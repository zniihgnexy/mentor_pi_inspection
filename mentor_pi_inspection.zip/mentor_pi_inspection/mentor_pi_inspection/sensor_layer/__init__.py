# Sensor abstraction layer
