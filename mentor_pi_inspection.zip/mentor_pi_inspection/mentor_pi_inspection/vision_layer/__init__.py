# Vision and recognition layer
